import "bulma/css/bulma.css";
import "tachyons/css/tachyons.css";

class Page extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <h4 className="title is-4 mt4">EyeSpace Home</h4>
      </div>
    );
  }
}

export default Page;
