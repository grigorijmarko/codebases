import Link from "next/link";
import client from "../../client";
import "bulma/css/bulma.css";
import "tachyons/css/tachyons.css";

class Page extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  static async getInitialProps() {
    const categories = await client.fetch('*[_type == "kbCategory"]');
    const posts = [];
    for (let i = 0; i < categories.length; i++) {
      const catId = categories[i]._id;
      const query = `*[_type == "kb-article" && references("${catId}")]{title, slug}`;
      posts.push(client.fetch(query));
    }

    for (let i = 0; i < categories.length; i++) {
      categories[i].articles = await posts[i];
    }

    return {
      categories
    };
  }

  render() {
    return (
      <div>
        {this.props.categories.map(cat => (
          <div>
            <h4 className="title is-4 mt4">{cat.title}</h4>
            {cat.articles.map(
              article =>
                article.slug && (
                  <p>
                    <Link href="/kb/[slug]" as={`/kb/${article.slug.current}`}>
                      <a>{article.title}</a>
                    </Link>
                  </p>
                )
            )}
          </div>
        ))}
      </div>
    );
  }
}

export default Page;
