import groq from "groq";
import imageUrlBuilder from "@sanity/image-url";
import BlockContent from "@sanity/block-content-to-react";
import client from "../../client";

class Page extends React.Component {
  static async getInitialProps(ctx) {
    // It's important to default the slug so that it doesn't return "undefined"
    //
    const query = groq`*[_type == "kb-article" && slug.current == $slug][0]{
      title,
      "name": author->name,
      "authorImage": author->image,
      body
    }`;
    const { slug = "" } = ctx.query;
    return client.fetch(query, { slug });
  }

  render() {
    const sup = props => {
      return <sup>{props.children}</sup>;
    };

    const {
      title = "Missing title",
      name = "Missing name",
      authorImage,
      body = []
    } = this.props;
    return (
      <div className="box">
        <h1 className="title">{title}</h1>
        <h5 className="subtitle is-5">by {name}</h5>
        {authorImage && (
          <div>
            <img
              alt="Author"
              src={imageUrlBuilder(client)
                .image(authorImage)
                .width(50)
                .url()}
            />
          </div>
        )}

        <div className="content mt4">
          <BlockContent
            blocks={body}
            serializers={{ marks: { sup } }}
            imageOptions={{ w: 1200, h: 1200, fit: "max" }}
            {...client.config()}
          />
        </div>
      </div>
    );
  }
}

export default Page;
