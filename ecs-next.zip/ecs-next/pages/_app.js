import App from "next/app";
import Link from "next/link";
import "tachyons/css/tachyons.css";
import "bulma/css/bulma.css";
import { FaHome, FaQuestion } from "react-icons/fa";

class MyApp extends App {
  static async getInitialProps(ctx) {
    const appProps = await App.getInitialProps(ctx);
    return { ...appProps };
  }

  render() {
    const { Component, pageProps } = this.props;
    return (
      <>
        <div className="container pb6">
          <div className="masthead bb pb2 mb4 mt2">
            <nav className="navbar">
              <div className="navbar-brand">
                <div className="navbar-item">
                  <img
                    src="/images/logo.jpg"
                    alt="EyeSpace"
                    style={{ height: 50 }}
                  />
                </div>

                <div className="navbar-item">
                  <Link href="https://cloud.eyespacelenses.com">
                    <a className="button">
                      <FaHome />
                    </a>
                  </Link>
                </div>

                <div className="navbar-item">
                  <Link href="/kb">
                    <a className="button">
                      <span className="icon is-small">
                        <FaQuestion />
                      </span>
                      <span>Knowledge Base</span>
                    </a>
                  </Link>
                </div>
              </div>
            </nav>
          </div>

          <div>
            <main>
              <Component {...pageProps} />
            </main>
          </div>
        </div>
      </>
    );
  }
}

export default MyApp;
