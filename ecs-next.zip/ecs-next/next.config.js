const withCSS = require('@zeit/next-css');


const client = require('./client')

module.exports = withCSS({
  exportPathMap: async function (defaultPathMap) {
    const paths = await client
      .fetch('*[_type == "kbArticle" && defined(slug)].slug.current')
      .then(data =>
        data.reduce(
          (acc, slug) => ({
            '/': { page: '/' },
            ...acc,
            [`/kb/${slug}`]: { page: '/kb/[slug]', query: { slug } }
          }),
          defaultPathMap
        )
      )
      .catch(console.error)
    return paths
  }
})
