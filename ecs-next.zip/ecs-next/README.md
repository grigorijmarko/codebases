## Eslint

Good starting point: https://github.com/Sly777/ran/blob/master/.eslintrc
