Really simple static site, built from metalsmith.
