<template>
  <div id="intro">
    <div class="">
      <div class="holder">
        <h2>What is EyeSpace?
          <br>And what can it do?</h2>
        <div class="row">
          <p class="col-lg-10">EyeSpace is an easy to use software program for rigid contact lens design and simulation. It imports data from
            your corneal topographer, and uses that information to design a rigid contact lens. It can be used to fit our
            specialty lens designs, to design your own lens, and as an educational tool.</p>
        </div>
        <div class="row">
          <p class="col-lg-10">We offer a complete system for fitting a wide variety of RGP lenses, and work closely with our distributors to
            provide class leading educational material and individual support.</p>
        </div>


        <h2>EyeSpace is free, and includes the following:</h2>
        <ol class="feature-list">
          <li>
            <p class="feature__p">EyeSpace software that links to your topographer for designing, simulating, and ordering lenses.</p>
          </li>
          <li>
            <p class="feature__p">A sample database and tutorials for learning how to design and order lenses.</p>
          </li>
          <li>
            <p class="feature__p">Access to our website for tracking and tracing your orders and patient history.</p>
          </li>
          <li>
            <p class="feature__p">Free set up and one-on-one training sessions via Skype, or in person if we have a representative nearby.</p>
          </li>
        </ol>

        <h2>Works with multiple topographers.
          <br>And more to come.</h2>
        <div class="row">
          <p class="col-md-8">EyeSpace currently supports the Medmont E300, Oculus Keratograph, and Oculus Pentacam. If you want to use EyeSpace
            with a topographer that is not listed here, then please to let us know
            <a href="/contact/">here</a>.</p>
        </div>

        <h2 class="team-h2">Meet the team.</h2>
        <h3 class="team-name mt-2">
          Jake Brown </h3>
        <p class="team-position">
          Managing Director, Biomedical Software Engineer </p>
        <div class="team-about">
          <p>BSc (High Performance Computational Physics) Honours</p>
        </div>
        <h3 class="team-name mt-2">
          Lachlan Scott-Hoy </h3>
        <p class="team-position">
          Clinical research and lens design </p>
        <div class="team-about">
          <p>BAppSc (Optometry) Honours
            <br /> PGCert (Ocular Therapeutics)</p>
        </div>
        <h3 class="team-name mt-2">
          Jagrut Lallu </h3>
        <p class="team-position">
          Patient education and marketing </p>
        <div class="team-about">
          <p>B Optom Hons, TPA</p>
        </div>
        <h3 class="team-name mt-2">
          Charl Laas </h3>
        <p class="team-position">
          Practitioner education </p>
        <div class="team-about">
          <p>B Optom (UJ)
            <br /> CAS (USA)
            <br /> BSc. Med. Sc (Hons) Epidemiology (Stell)
            <br /> MDP (Stell)</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
};
</script>

<style scoped>
</style>
