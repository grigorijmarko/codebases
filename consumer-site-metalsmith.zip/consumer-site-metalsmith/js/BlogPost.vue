<template>
  <div
    v-if="post.data"
    id="blog-post"
  >
    <h1>{{ post.data.title }}</h1>
    <h4>{{ post.data.author.first_name }} {{ post.data.author.last_name }}</h4>
    <div v-html="post.data.body"/>

    <router-link
      v-if="post.meta.previous_post"
      :to="/blog/ + post.meta.previous_post.slug"
      class="button">
      {{ post.meta.previous_post.title }}
    </router-link>
    <router-link
      v-if="post.meta.next_post"
      :to="/blog/ + post.meta.next_post.slug"
      class="button">
      {{ post.meta.next_post.title }}
    </router-link>
  </div>
</template>

<script>
import butter from './buttercms';

export default {
  name: 'BlogPost',
  data() {
    return {
      post: {},
    };
  },
  mounted() {
    this.getPost();
  },
  methods: {
    getPost() {
      // eslint-disable-next-line
      butter.post.retrieve(this.$route.params.slug)
        .then((res) => {
          // eslint-disable-next-line
          this.post = res.data;
        }).catch((err) => {
          // eslint-disable-next-line
          console.log(err);
        });
    },
  },
};
</script>

<style lang="scss" scoped>

#blog-post /deep/ {

margin-bottom: 100px;

h1, h2, h3, h4, h5 {
    font-weight: 600;
    margin-bottom: 1em;
}

h1 {
font-size: 48px;
}

h2 {
font-size: 32px;
margin-top: 50px;
}

img {
  width: 100%;
  padding: 50px;
}

ul, ol {
  margin-bottom: 1.25em;
}

li {
    margin-bottom: 0.25em;
}

p {
  font-size: 1.05em;
  line-height: 1.58;
  margin-bottom: 0.6em;
  font-weight: 400;
  letter-spacing: 0.01em;
}

/* Responsive floating */
@media only screen and (min-width: 720px)  {
  .butter-float-left {
    float: left;
    margin: 0px 10px 10px 0px;
  }

  .butter-float-right {
    float: right;
    margin: 0px 0px 10px 10px;
  }
}

/* Image caption */
figcaption {
  font-style: italic;
  text-align: center;
  color: #ccc;
}

p code {
  padding: 2px 4px;
  font-size: 90%;
  color: #c7254e;
  background-color: #f9f2f4;
  border-radius: 4px;
  font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
}

pre {
  display: block;
  padding: 1em;
  margin: 0 0 2em;
  font-size: 1em;
  line-height: 1.4;
  word-break: break-all;
  word-wrap: break-word;
  color: #333333;
  background-color: #f5f5f5;
  font-family: Menlo, Monaco,Consolas, "Courier New", monospace;
}

}

</style>

<docs>
Because butter pulls this in with the v-html attribute, we need to use a deep selector:
https://medium.com/@brockreece/scoped-styles-with-v-html-c0f6d2dc5d8e
https://github.com/vuejs/vue-loader/issues/661
</docs>
