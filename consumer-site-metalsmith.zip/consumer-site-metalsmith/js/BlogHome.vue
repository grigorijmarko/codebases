<template>
  <div id="blog-home">
    <div
      v-for="(post,index) in posts"
      :key="post.slug + '_' + index">
       <router-link :to="'/practitioner/blog/' + post.slug">
        <article class="media">
          <h2>{{ post.title }}</h2>
          <div class="post-preview">
            <figure>
              <!-- Bind results using a ':' -->
              <!-- Use a v-if/else if their is a featured_image -->
              <img
                v-if="post.featured_image"
                :src="post.featured_image"
                alt="">
              <img
                v-else
                src="http://via.placeholder.com/250x250"
                alt="">
            </figure>
            <p class="post-summary">{{ post.summary }}</p>
          </div>
        </article>
      </router-link>
    </div>
  </div>
</template>

<script>
import butter from './buttercms';

export default {
  name: 'BlogHome',
  data() {
    return {
      page_title: 'Blog',
      posts: [],
    };
  },
  created() {
    this.getPosts();
  },
  methods: {
    getPosts() {
      butter.post
        .list({
          page: 1,
          page_size: 10,
        })
        .then((res) => {
          this.posts = res.data.data;
        });
    },
  },
};
</script>

<style scoped>

article {
  display: block;
  margin-bottom: 50px;
}

.post-summary {
  margin-left: 20px;
}

.post-preview {
  padding: 10px;
  display: flex;
  margin-left: auto;
  margin-right: auto;
}

img {
  max-height: 300px;
  width: 200px!important;
  display: block;
}

h2 {
  font-size: 24px;
  margin: 10px;
  margin-top: 0px;
  color: black;
  opacity: 0.7;
}

p {
  color: black;
  opacity: 0.6;
  opacity: 0.6;
}

</style>
