import '../scss/main.scss';
import 'typeface-poppins';
import Vue from 'vue/dist/vue.js'
import Router from 'vue-router';
import BlogHome from './BlogHome.vue';
import BlogPost from './BlogPost.vue';
import Contact from './Contact.vue';
import Intro from './Intro.vue';

Vue.use(Router);

const router = new Router({
  routes: [
    {
      path: '/practitioner',
      name: 'intro',
      component: Intro,
    },
    {
      path: '/practitioner/contact',
      name: 'contact',
      component: Contact,
    },
    {
      path: '/practitioner/blog',
      name: 'blog-home',
      component: BlogHome,
    },
    {
      path: '/practitioner/blog/:slug/',
      name: 'blog-post',
      component: BlogPost,
    },
  ],
});

// eslint-disable-next-line
(new Vue({
  router,
})).$mount('#app');
// eslint-disable-next-line
console.log("Mounted vue");
