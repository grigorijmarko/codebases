<template>
<div>
    <div class="container-fluid hero-black pt-10 pb-7 mb-5">
    <div class="container">
      <div class="row">
        <div class="col-md-7 offset-md-1">
          <h1>
            Contact Us          </h1>
            <div class="hero__intro">
              <p>We work closely with our distributors to bring you the best service possible. Your local distributor should be your first point of call for service and support.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="container simple-text pb-10">
        <div class="row">
          <div class="col-md-7 offset-md-1">
            <h2>United States 🇺🇸</h2>
            <p><strong>Custom Craft Lens Service</strong></p>
            <p>We are proud to announce that Custom Craft Lens Service will be the exclusive manufacturer and distributor of EyeSpace lenses in the USA!</p>
            <p>Since 1982 Custom Craft Lens Service has maintained one singular focus, manufacturing contact lenses to the highest quality and consistency. Custom Craft was the first lab in the USA to employ the gold standard Optoform lathe, and continues to innovate the contact lens industry.</p>
            <p> <a href="http://www.eyespaceus.com/">Click here</a> for further details.</p>
            <h2>Australia 🇦🇺</h2>
            <p><strong>Innovative Contacts Australia</strong></p>
            <p>Based in Adelaide South Australia, Innovative Contacts supplies speciality lenses and world-class support to practitioners in Australia and New Zealand.</p>
            <p>The team at Innovative Contacts is passionate about speciality contact lenses designed from corneal topography, and the role they can play to assist building optometric practices.</p>
            <p><a href="http://innovativecontacts.com.au/">Click here to visit their website.</a></p>
            <p>Contact Details:  Bray House, 60 Hutt Street Adelaide, SA 5000</p>
            <p><strong>Kendrew Smith, Managing Director</strong></p>
            <ul>
              <li>Email: kendrew@innovativecontacts.com.au</li>
              <li>Ph: 0468333150</li>
            </ul>
            <p><strong>Kristin Pokley, Technical Consultant &amp; Sales</strong></p>
            <ul>
              <li>Email: <a href="mailto:&#107;&#x72;&#x69;&#x73;&#x74;&#105;&#110;&#64;&#x69;&#x6e;&#x6e;&#111;&#x76;&#97;&#116;&#x69;&#x76;&#x65;&#x63;&#111;&#110;&#x74;&#97;&#x63;&#x74;&#115;&#46;&#99;&#111;&#109;&#x2e;&#97;&#x75;">kristin@innovativecontacts.com.au</a></li>
              <li>Ph: 0409224591</li>
            </ul>
            <h2>New Zealand 🇳🇿</h2>
            <p><strong>Corneal Lens Corporation</strong></p>
            <p>Originally purchased by Ed Curtis, CLC made its first lenses in Christchurch on April 18, 1971. Some 43 years later and now owned by his son Graeme Curtis, the business has expanded and developed into one of the most modern contact lens laboratories in Australasia with purpose built manufacturing premises in Wigram, Christchurch, completed late 2013.</p>
            <p><a href="http://corneal-lens.co.nz/">Visit their website here.</a></p>
            <h2>South Africa 🇿🇦</h2>
            <p><strong>Innovative Contacts South Africa</strong></p>
            <p>Innovative Contacts South Africa is a dynamic contact lens company that moves quickly to bring leading specialty contact lens designs and products to the South African optometry market.</p>
            <p>They are passionate about specialty contact lenses designed from corneal topography data and the role we can play to assist building optometric practices.</p>
            <p>It is their passion for people to experience the freedom and benefits which specialty contact lenses provides and they strive to support and educate all contact lens practitioners who are interested in the art and science of specialty contact lens fitting.</p>
            <p><a href="http://www.innovativecontactssa.com/">Visit their website here.</a></p>        </div>
          </div>
        </div>
      </div>
</div>
</template>

<script>
</script>

<style scoped>
</style>
