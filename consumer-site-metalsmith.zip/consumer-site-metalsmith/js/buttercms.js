import Butter from 'buttercms';

const butter = Butter('88a6f368ea4abf8558c5c9e8b5b3263b63c6168d');
export default butter;
