const Metalsmith = require('metalsmith')
const handlebars = require('metalsmith-handlebars')
var parcel = require('metalsmith-parcel')
var watch = require('metalsmith-watch');

Metalsmith(__dirname)
  .metadata({
    title: "My Static Site & Blog",
    description: "It's about saying »Hello« to the World.",
    generator: "Metalsmith",
    url: "http://www.metalsmith.io/"
  })
  .source('src')
  .destination('build')
  .clean(false)
  .use(handlebars({
    partials: './partials/', 
    pattern: '**/*.hbs',
    targetExtension: 'html', 
  }))
  .use(parcel('js/index.js', {
    watch: false,
    outDir: 'build/',
  }))
  .use(parcel('js/consumer-site.js', {
    watch: false,
    outDir: 'build/',
  }))
  .build(function (err) {
    if (err) { throw err }
  })